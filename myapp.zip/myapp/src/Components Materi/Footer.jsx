import React from 'react'

const Footer = () => {
  return (
    <div>
      <h1>FOOTER</h1>
    </div>
  )
}

export default Footer