import React from 'react'

const AboutMe = () => {
  return (
    <div>
        <h1>ABOUTME</h1>
    </div>
  )
}

export default AboutMe