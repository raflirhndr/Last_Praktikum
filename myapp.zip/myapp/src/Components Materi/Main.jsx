import React, { useEffect, useState } from "react";
import './main.css'


export function Main() {
  const [data, setData] = useState(null);

  useEffect(() => {
    fetch("https://restaurant-api.dicoding.dev/list")
      .then(response => response.json())
      .then((json) => setData(json.restaurants));
  }, []);

  if (!data) {
    return <p>Loading...</p>;
  }

  return (
    <div>
      <h2>Rekomendasi Restaurant </h2> <hr />
    <ul>
      {data.map(item => (
        <div className="List">
        <img src={"https://restaurant-api.dicoding.dev/images/small/" + item.pictureId} alt="" /><br/>
        <li key={item.id} >Nama Restaurant      : <b>{item.name}</b></li><br/>
        <li key={item.id} >Deskripsi Restaurant :<br/> {item.description}</li><br/>
        <li key={item.id} >Lokasi               : {item.city} <hr /></li><br/>
        </div>
      ))}
    </ul>
    </div>
  );
}
