import React from "react";
import { BrowserRouter as Router, Route, Routes, Link } from "react-router-dom";
import {Main} from './Components Materi/Main'
import Navbar from "./Components Materi/Navbar";
import AboutMe from "./Components Materi/AboutMe";
import Contact from "./Components Materi/Contact";
import Footer from "./Components Materi/Footer";
import './style.css'

function App() {
  return (
    <Router>
      <Navbar />
      <Routes>
        <Route index="/" element={<Main />} />
        <Route path="about" element={<AboutMe />} />
        <Route path="contact" element={<Contact />} />
      </Routes>
    </Router>
  );
}

export default App;



